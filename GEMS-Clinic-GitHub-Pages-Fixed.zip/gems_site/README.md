# GEMS Telemedicine Clinic – GitHub Pages

1. Upload `index.html` and `.nojekyll` to the repository root.
2. Keep `index.html` exactly at the root of the published branch/folder.
3. GitHub: Settings → Pages → Deploy from a branch → select the branch and `/ (root)`.
4. Open the generated Pages URL after the deployment finishes.

Notes:
- This is a static GitHub Pages application. Data is stored in the browser with localStorage, so it is not a shared multi-user database.
- PDF generation uses the jsPDF CDN. If that CDN is unavailable, the prescription Print Card fallback remains available.
- Tailwind CSS and Font Awesome are loaded from public CDNs.
